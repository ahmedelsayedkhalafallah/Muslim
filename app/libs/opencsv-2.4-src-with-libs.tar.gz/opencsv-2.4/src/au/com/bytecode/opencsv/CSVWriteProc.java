package au.com.bytecode.opencsv;

public interface CSVWriteProc {
	void process(CSVWriter out);
}
